from flask import Flask, session


app = Flask(__name__)


@app.route('/set_session')
def set_session():
    session['username'] = 'heyalu'
    return 'set session sucess'



@app.route('/get_session')
def set_session():
    username = session['username']
    return 'get session sucess'.format(username)

