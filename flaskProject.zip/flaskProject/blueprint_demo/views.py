from . import blueprint_demo


@blueprint_demo.route('/blueprint_demo')
def demo():
    return 'demo'
