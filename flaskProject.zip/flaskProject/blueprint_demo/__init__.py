from flask import Blueprint

blueprint_demo = Blueprint('blueprint_demo', __name__)

# from . import views
from .views import *
# 这一句要放在后面，放在上面会循环引用