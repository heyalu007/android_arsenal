from flask import Flask, render_template
from flask import redirect
from flask import jsonify
from flask import make_response

import pymysql
import json
from blueprint_demo import blueprint_demo
from werkzeug.routing import BaseConverter

# 初始化flask对象
app = Flask(__name__)
# 传入__name__是告诉Flask对象根目录的地址，Flask会在这个目录下寻找static、templates等文件夹


app.register_blueprint(blueprint_demo, url_prefix='/bp_demo')


class DefaultConfig(object):
    """
    默认配置信息
    """
    SECRET_KEY = 'TaTaHshHsh'


app.config.from_object(DefaultConfig)
# app.config.from_pyfile('setting.py')
# app.config.from_envvar('PROJECT_SETTING', silent=True)


@app.route('/', methods=['GET'])
def hello_world():  # put application's code here
    return 'Hello Heyalu!'


@app.route('/demo')
def demo():
    return 'demo', 200, {'temp': 'Python'}  # {response, status, headers}


@app.route('/cookie')
def set_cookie():
    rsp = make_response('cookie_test')
    rsp.delete_cookie('token')
    return rsp


# static 主要放css和js文件
# templates 主要放网页模板


def get_conn():
    """
    获取数据库的链接
    :return:
    """
    return pymysql.connect(
        host='127.0.0.1',
        user='root',
        password='1234567',
        database='test',
        charset='utf8'
    )


# def query_mysql_data(data_id):
#     """
#     查询数据库类型
#     :param data_id:
#     :return:
#     """
#     conn = get_conn()
#     sql = """
#         select * from tb_data where id={data_id}
#     """
#     cursor = conn.cursor()
#     cursor.execute(sql)
#     conn.close()
#     return cursor.fetchall()


# @app.route('/query_data/<int: data_id>')
# def query_data(data_id):
#     return 'query data {}'.format(data_id)
#     # return json.dumps(
#     #     query_mysql_data(data_id)
#     # )



print(app.url_map)
print(app.url_map.iter_rules())

if __name__ == '__main__':
    app.run(debug=True)
