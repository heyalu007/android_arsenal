from flask import Flask, session

app = Flask(__name__)


@app.errorhandler(400)
def bad_request_err():
    return '网络请求出错了'


@app.errorhandler(ZeroDivisionError)
def zero_division_error():
    return '不能除以0哦'